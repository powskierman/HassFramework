//
//  HassRestClient.swift
//  HassFramework
//
//  Created by Michel Lapointe on 2023-12-31.
//  Refactored by ChatGPT on 2025-08-10
//

import Foundation
import Combine

public final class HassRestClient {
    public static let shared = HassRestClient()

    private let baseURL: URL
    private let session: URLSession
    private let authToken: String
    
    /// Toggle debug logging on/off
    private let debugMode = true
    
    // MARK: - JSON Helpers
    private let jsonEncoder: JSONEncoder = {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        return encoder
    }()
    
    private let jsonDecoder: JSONDecoder = {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }()
    
    // MARK: - Init
    private init() {
        let secrets = HassRestClient.loadSecrets()
        guard let serverURLString = secrets?["RESTURL"] as? String,
              let token = secrets?["authToken"] as? String,
              let baseURL = URL(string: serverURLString) else {
            fatalError("Invalid or missing URL or auth token in Secrets.plist.")
        }
        
        self.baseURL = baseURL
        self.authToken = token
        self.session = URLSession(configuration: .default)
    }
    
    public init(baseURL: URL, authToken: String, session: URLSession = .shared) {
        self.baseURL = baseURL
        self.authToken = authToken
        self.session = session
    }
    
    // MARK: - Secrets Loader
    private static func loadSecrets() -> [String: Any]? {
        guard let path = Bundle.main.path(forResource: "Secrets", ofType: "plist") else {
            print("Error: Secrets.plist file not found.")
            return nil
        }
        
        guard let dictionary = NSDictionary(contentsOfFile: path) as? [String: Any] else {
            print("Error: Unable to read or cast Secrets.plist as a dictionary.")
            return nil
        }
        
        return dictionary
    }
    
    // MARK: - Logging
    private func log(_ message: String) {
        if debugMode { print("[HassRestClient] \(message)") }
    }
    
    // MARK: - Core Request (Expecting Response)
    private func performRequest<T: Decodable>(
        endpoint: String,
        method: String = "GET",
        body: Data? = nil,
        completion: @escaping (Result<T, HassError>) -> Void
    ) {
        var request = URLRequest(url: baseURL.appendingPathComponent(endpoint))
        request.httpMethod = method
        request.addValue("Bearer \(authToken)", forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = body
        
        log("➡️ \(method) \(request.url?.absoluteString ?? "N/A")")
        if let body = body, let jsonString = String(data: body, encoding: .utf8) {
            log("Request Body: \(jsonString)")
        }
        
        session.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(.networkError(error)))
                return
            }
            guard let httpResponse = response as? HTTPURLResponse else {
                completion(.failure(.invalidResponse))
                return
            }
            self.log("⬅️ Status Code: \(httpResponse.statusCode)")
            
            guard let data = data, !data.isEmpty else {
                completion(.failure(.noData))
                return
            }
            
            do {
                let decoded = try self.jsonDecoder.decode(T.self, from: data)
                completion(.success(decoded))
            } catch {
                completion(.failure(.decodingError(error)))
            }
        }.resume()
    }
    
    // MARK: - Core Request (No Response Expected)
    private func performRequestNoResponse(
        endpoint: String,
        method: String = "POST",
        body: Data? = nil,
        completion: @escaping (Result<Void, HassError>) -> Void
    ) {
        performRequest(endpoint: endpoint, method: method, body: body) { (result: Result<EmptyResponse, HassError>) in
            switch result {
            case .success:
                completion(.success(()))
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }
    
    // MARK: - Public API
    
    public func sendDeviceToken(_ deviceToken: String, completion: @escaping (Result<Void, HassError>) -> Void) {
        let endpoint = "api/push_token"
        let body = ["token": deviceToken]
        guard let bodyData = try? jsonEncoder.encode(body) else {
            completion(.failure(.encodingError))
            return
        }
        performRequestNoResponse(endpoint: endpoint, method: "POST", body: bodyData, completion: completion)
    }
    
    public func fetchDeviceState(deviceId: String, completion: @escaping (Result<DeviceState, HassError>) -> Void) {
        performRequest(endpoint: "api/states/\(deviceId)", completion: completion)
    }
    
    public func sendCommandToDevice(deviceId: String, command: DeviceCommand, completion: @escaping (Result<CommandResponse, HassError>) -> Void) {
        guard let body = try? jsonEncoder.encode(command) else {
            completion(.failure(.encodingError))
            return
        }
        performRequest(endpoint: command.endpoint, method: command.method, body: body, completion: completion)
    }
    
    public func callService(domain: String, service: String, entityId: String, completion: @escaping (Result<Void, HassError>) -> Void) {
        let endpoint = "api/services/\(domain)/\(service)"
        let body = ToggleServiceRequest(entityId: entityId)
        
        guard let bodyData = try? jsonEncoder.encode(body) else {
            completion(.failure(.encodingError))
            return
        }
        
        performRequestNoResponse(endpoint: endpoint, method: "POST", body: bodyData, completion: completion)
    }
    
    public func callScript(entityId: String, completion: @escaping (Result<Void, HassError>) -> Void) {
        let endpoint = "api/services/script/turn_on"
        let body = ["entity_id": entityId]
        guard let bodyData = try? jsonEncoder.encode(body) else {
            completion(.failure(.encodingError))
            return
        }
        performRequestNoResponse(endpoint: endpoint, method: "POST", body: bodyData, completion: completion)
    }
    
    public func changeState<EntityState: Encodable>(entityId: String, newState: EntityState, completion: @escaping (Result<HAEntity, HassError>) -> Void) {
        let endpoint = "api/states/\(entityId)"
        let payload = ChangeStatePayload(entityId: entityId, state: newState)
        
        guard let bodyData = try? jsonEncoder.encode(payload) else {
            completion(.failure(.encodingError))
            return
        }
        performRequest(endpoint: endpoint, method: "POST", body: bodyData, completion: completion)
    }
    
    public func fetchState(entityId: String, completion: @escaping (Result<HAEntity, HassError>) -> Void) {
        let endpoint = "api/states/\(entityId)"
        performRequest(endpoint: endpoint) { (result: Result<HAEntity, HassError>) in
            switch result {
            case .success(let entity):
                completion(.success(entity))
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }
    
    // MARK: - Combine Support
    public func requestPublisher<T: Decodable>(
        endpoint: String,
        method: String = "GET",
        body: Data? = nil
    ) -> AnyPublisher<T, HassError> {
        Future { promise in
            self.performRequest(endpoint: endpoint, method: method, body: body, completion: promise)
        }
        .eraseToAnyPublisher()
    }
    
    // MARK: - Models
    
    public struct DeviceState: Decodable { }
    
    public struct CommandResponse: Decodable { }
    
    public struct DeviceCommand: Encodable {
        public let service: String
        public let entityId: String
        public let data: [String: AnyEncodable]
        
        public var endpoint: String { "api/services/\(service)" }
        public var method: String { "POST" }
        
        public init<T: Encodable>(service: String, entityId: String, data: T) {
            self.service = service
            self.entityId = entityId
            self.data = ["entity_id": AnyEncodable(entityId)]
                .merging(AnyEncodable.dictionary(from: data)) { $1 }
        }
        
        public func encode(to encoder: Encoder) throws {
            var container = encoder.container(keyedBy: DynamicCodingKeys.self)
            for (key, value) in data {
                try container.encode(value, forKey: DynamicCodingKeys(stringValue: key)!)
            }
        }
    }
    
    public struct AnyEncodable: Encodable {
        private let encodeFunc: (Encoder) throws -> Void
        public init<T: Encodable>(_ value: T) { self.encodeFunc = { try value.encode(to: $0) } }
        public func encode(to encoder: Encoder) throws { try encodeFunc(encoder) }
        
        static func dictionary<T: Encodable>(from value: T) -> [String: AnyEncodable] {
            guard let dict = try? JSONSerialization.jsonObject(with: JSONEncoder().encode(value)) as? [String: Any] else { return [:] }
            return dict.mapValues { AnyEncodable($0 as! Encodable) }
        }
    }
    
    struct DynamicCodingKeys: CodingKey {
        var stringValue: String
        init?(stringValue: String) { self.stringValue = stringValue }
        var intValue: Int? { nil }
        init?(intValue: Int) { nil }
    }
    
    struct ChangeStatePayload<EntityState: Encodable>: Encodable {
        let entityId: String
        let state: EntityState
    }
    
    struct EmptyResponse: Decodable { }
}

// MARK: - Errors
public enum HassError: Error {
    case invalidResponse
    case noData
    case encodingError
    case decodingError(Error)
    case networkError(Error)
    case unexpectedResponseType
    case entityNotFound
}
